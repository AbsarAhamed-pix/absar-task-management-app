# Task Management Application

**Thiranex Internship — Task 2**

A complete, responsive, full-stack **Task Management Application** built for **Absar Ahamed** (2nd Year, B.E. Computer Science and Engineering, **Easwari Engineering College, Chennai**).

---

## 1. Student & Project Details

- **Name:** Absar Ahamed
- **College:** Easwari Engineering College, Chennai
- **Department:** Computer Science and Engineering
- **Year:** 2nd Year
- **Project:** Task Management Application (Thiranex Internship Task 2)
- **GitHub Repository Name:** `absar-task-management-app`

---

## 2. Technology Stack & Architecture

| Layer | Technology | Purpose |
| :--- | :--- | :--- |
| **Frontend** | React 19, TypeScript, Tailwind CSS v4, Vite | Responsive dashboard, task CRUD modals, live search/filter/sort, Light/Dark theme |
| **Backend** | Node.js, Express.js | REST API endpoints, input validation, error handling, JWT & ownership middleware |
| **Authentication** | `jsonwebtoken` (JWT) + `bcryptjs` | Salted password hashing, stateless Bearer tokens, strict per-user authorization |
| **Database** | MongoDB / MongoDB Atlas (`mongoose`) | `users` and `tasks` collections (with persistent local JSON fallback when `MONGODB_URI` is empty) |
| **Real-Time** | Socket.IO | Authenticated per-user room (`user:<userId>`) emitting `task:created`, `task:updated`, `task:deleted` |

### Project Structure

```text
absar-task-management-app/
├── index.html                  # HTML5 entry point & font imports
├── server.ts                   # HTTP + Express + Socket.IO + Vite server entry point
├── package.json                # Dependencies & scripts
├── .env.example                # Environment variable template (no secrets)
├── src/                        # Frontend (React + Tailwind CSS)
│   ├── App.tsx                 # Workspace state, JWT memory session & Socket.IO listener
│   ├── index.css               # Tailwind v4 & Light/Dark mode config
│   ├── types.ts                # Frontend interfaces
│   ├── lib/api.ts              # Typed REST API client
│   └── components/
│       ├── AuthScreen.tsx      # Login & Registration views
│       ├── Sidebar.tsx         # Responsive sidebar + mobile drawer
│       ├── DashboardView.tsx   # KPI cards, statistics & recent tasks
│       ├── TasksView.tsx       # Search, filters, sorting & task cards
│       ├── TaskModals.tsx      # Create/Edit, View Details & Delete Confirmation modals
│       └── ProfileView.tsx     # User profile & display name editor
└── server/                     # Backend (Express + Mongoose + JWT + Socket.IO)
    ├── db.ts                   # MongoDB Atlas schemas (users, tasks) & local fallback
    ├── auth.ts                 # Bcrypt hashing, JWT verification & owner authorization
    ├── realtime.ts             # Per-user authenticated Socket.IO rooms
    ├── routes.ts               # Auth, profile & Task CRUD REST API routes
    ├── validation.ts           # Request payload & NoSQL operator sanitization
    └── types.ts                # Shared backend interfaces
```

---

## 3. MongoDB Collections

1. **`users`**: `id`, `name`, `email` (unique, lowercase), `passwordHash` (bcrypt), `createdAt`, `updatedAt`.
2. **`tasks`**: `id`, `title`, `description`, `priority` (`High` | `Medium` | `Low`), `status` (`Pending` | `Completed`), `dueDate` (`YYYY-MM-DD`), `userId` (indexed), `createdAt`, `updatedAt`.

Every task query and mutation validates JWT authentication and checks `task.userId === req.user.id`, ensuring users can never read, modify, or delete another user's tasks.

---

## 4. REST API Documentation

### Authentication & Profile
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/health` | Public | Server health, database mode, and Socket.IO status |
| `POST` | `/api/auth/register` | Public | Register user (`name`, `email`, `password`) and return JWT |
| `POST` | `/api/auth/login` | Public | Verify credentials with bcrypt and return JWT |
| `POST` | `/api/auth/logout` | JWT | Acknowledge user sign-out |
| `GET` | `/api/auth/profile` | JWT | Retrieve authenticated user profile and task stats |
| `PUT` | `/api/auth/profile` | JWT | Update authenticated user display name |

### Task Management (All Protected by JWT + Per-User Ownership)
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/tasks` | JWT | List user's tasks (`?status=`, `?priority=`, `?search=`, `?sortBy=`, `?sortOrder=`) |
| `GET` | `/api/tasks/:id` | JWT + Owner | Retrieve single task details |
| `POST` | `/api/tasks` | JWT | Create a new task and emit Socket.IO `task:created` |
| `PUT` | `/api/tasks/:id` | JWT + Owner | Update task title, description, priority, due date, or status (`task:updated`) |
| `DELETE` | `/api/tasks/:id` | JWT + Owner | Delete a task (`task:deleted`) |

---

## 5. Local Installation & Running

1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy `.env.example` to `.env`:
   ```env
   MONGODB_URI="mongodb+srv://<username>:<password>@<cluster>.mongodb.net/absar_task_manager?retryWrites=true&w=majority"
   JWT_SECRET="replace-with-a-long-random-secret-key"
   PORT=3000
   ```
3. Start development server:
   ```bash
   npm run dev
   ```
4. Build and run production bundle:
   ```bash
   npm run build
   npm start
   ```

---

## 6. Browser-Only GitHub & Deployment Guide (No VS Code Needed)

1. **Download ZIP:** Click **Download / Export** in Google AI Studio and unzip the folder.
2. **Create GitHub Repo:** Go to `https://github.com/new` in Chrome, name the repository **`absar-task-management-app`**, choose **Public**, and click **Create repository**.
3. **Upload Files:** Click **uploading an existing file**, upload all files/folders except `node_modules` and `.env`, and commit.
4. **MongoDB Atlas:** Create a free M0 cluster on `https://www.mongodb.com/atlas`, add a database user, allow `0.0.0.0/0` in Network Access, and copy `MONGODB_URI`.
5. **Deploy Full-Stack (Render):** Connect `absar-task-management-app` on `https://render.com` as a Web Service (`npm install && npm run build`, start `npm start`), add `MONGODB_URI`, `JWT_SECRET`, and `NODE_ENV=production`, then verify your live URL.
