import http from 'node:http';
import path from 'node:path';
import cors from 'cors';
import 'dotenv/config';
import express, { type NextFunction, type Request, type Response } from 'express';
import helmet from 'helmet';
import { createServer as createViteServer } from 'vite';
import { initDatabase } from './server/db.ts';
import { initRealtimeServer } from './server/realtime.ts';
import { apiRouter } from './server/routes.ts';

async function startServer() {
  await initDatabase();

  const app = express();
  const httpServer = http.createServer(app);
  initRealtimeServer(httpServer);

  const port = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  app.use(
    helmet({
      contentSecurityPolicy: false,
      frameguard: false,
      crossOriginEmbedderPolicy: false,
    }),
  );

  app.use(
    cors({
      origin: (origin, callback) => {
        if (!origin) {
          callback(null, true);
          return;
        }
        const appUrl = process.env.APP_URL?.trim();
        if (
          origin.startsWith('http://localhost:') ||
          origin.startsWith('http://127.0.0.1:') ||
          (appUrl && origin === appUrl) ||
          origin.endsWith('.run.app')
        ) {
          callback(null, true);
          return;
        }
        callback(null, false);
      },
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
      allowedHeaders: ['Content-Type', 'Authorization'],
    }),
  );

  app.use(express.json({ limit: '1mb' }));

  app.use('/api', apiRouter);

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distDir, 'index.html'));
    });
  }

  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    console.error('Server error:', err);
    if (res.headersSent) {
      return;
    }
    res.status(500).json({
      error: 'An unexpected server error occurred. Please try again.',
    });
  });

  httpServer.listen(port, '0.0.0.0', () => {
    console.log(`Task Management server (HTTP + Socket.IO) listening on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
