import { Router } from 'express';
import {
  authenticateJwt,
  authorizeTaskOwner,
  hashPassword,
  signJwtToken,
  verifyPassword,
  type AuthenticatedRequest,
} from './auth.ts';
import {
  createTask,
  createUser,
  deleteTaskForUser,
  findUserByEmail,
  getDatabaseMode,
  listTasksForUser,
  toPublicUser,
  updateTaskForUser,
  updateUserName,
} from './db.ts';
import {
  emitTaskCreated,
  emitTaskDeleted,
  emitTaskUpdated,
  isRealtimeActive,
} from './realtime.ts';
import type { TaskPriority, TaskRecord, TaskStats, TaskStatus } from './types.ts';
import {
  cleanText,
  validateLoginInput,
  validateProfileUpdateInput,
  validateRegisterInput,
  validateTaskInput,
} from './validation.ts';

export const apiRouter = Router();

function computeStats(tasks: TaskRecord[]): TaskStats {
  const todayIso = new Date().toISOString().slice(0, 10);
  let pending = 0;
  let completed = 0;
  let overdue = 0;
  let highPriority = 0;
  let mediumPriority = 0;
  let lowPriority = 0;

  for (const task of tasks) {
    if (task.status === 'Completed') {
      completed += 1;
    } else {
      pending += 1;
      if (task.dueDate < todayIso) {
        overdue += 1;
      }
    }
    if (task.priority === 'High') highPriority += 1;
    else if (task.priority === 'Medium') mediumPriority += 1;
    else lowPriority += 1;
  }

  return {
    total: tasks.length,
    pending,
    completed,
    overdue,
    highPriority,
    mediumPriority,
    lowPriority,
  };
}

apiRouter.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    database: getDatabaseMode(),
    realtime: isRealtimeActive() ? 'socket.io' : 'polling',
    timestamp: new Date().toISOString(),
  });
});

// ==================== AUTH ROUTES ====================

apiRouter.post('/auth/register', async (req, res, next) => {
  try {
    const validation = validateRegisterInput(req.body);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const existing = await findUserByEmail(validation.data.email);
    if (existing) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const passwordHash = await hashPassword(validation.data.password);
    const created = await createUser({
      name: validation.data.name,
      email: validation.data.email,
      passwordHash,
    });

    const user = toPublicUser(created);
    const token = signJwtToken(user);

    res.status(201).json({
      token,
      user,
      message: 'Account created successfully.',
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/auth/login', async (req, res, next) => {
  try {
    const validation = validateLoginInput(req.body);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const userRecord = await findUserByEmail(validation.data.email);
    if (!userRecord) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const isMatch = await verifyPassword(validation.data.password, userRecord.passwordHash);
    if (!isMatch) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const user = toPublicUser(userRecord);
    const token = signJwtToken(user);

    res.json({
      token,
      user,
      message: 'Signed in successfully.',
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.post('/auth/logout', authenticateJwt, (_req, res) => {
  res.json({ message: 'Signed out successfully.' });
});

apiRouter.get('/auth/profile', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const allTasks = await listTasksForUser(req.user.id);
    res.json({
      user: req.user,
      stats: computeStats(allTasks),
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.put('/auth/profile', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const validation = validateProfileUpdateInput(req.body);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }
    const updated = await updateUserName(req.user.id, validation.data.name);
    if (!updated) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    res.json({
      user: toPublicUser(updated),
      message: 'Profile updated successfully.',
    });
  } catch (err) {
    next(err);
  }
});

// ==================== TASK CRUD ROUTES ====================

apiRouter.get('/tasks', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }

    const statusParam = typeof req.query.status === 'string' ? req.query.status : undefined;
    const priorityParam = typeof req.query.priority === 'string' ? req.query.priority : undefined;
    const searchParam = typeof req.query.search === 'string' ? cleanText(req.query.search, 120) : undefined;
    const sortByParam = req.query.sortBy === 'createdAt' ? 'createdAt' : 'dueDate';
    const sortOrderParam = req.query.sortOrder === 'desc' ? 'desc' : 'asc';

    const status: TaskStatus | undefined =
      statusParam === 'Pending' || statusParam === 'Completed' ? statusParam : undefined;
    const priority: TaskPriority | undefined =
      priorityParam === 'High' || priorityParam === 'Medium' || priorityParam === 'Low'
        ? priorityParam
        : undefined;

    const [filteredTasks, allTasks] = await Promise.all([
      listTasksForUser(req.user.id, {
        status,
        priority,
        search: searchParam,
        sortBy: sortByParam,
        sortOrder: sortOrderParam,
      }),
      listTasksForUser(req.user.id),
    ]);

    res.json({
      tasks: filteredTasks,
      stats: computeStats(allTasks),
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.get(
  '/tasks/:id',
  authenticateJwt,
  authorizeTaskOwner,
  (req: AuthenticatedRequest, res) => {
    res.json({ task: req.taskResource });
  },
);

apiRouter.post('/tasks', authenticateJwt, async (req: AuthenticatedRequest, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }

    const validation = validateTaskInput(req.body, false);
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const created = await createTask({
      title: validation.data.title!,
      description: validation.data.description ?? '',
      priority: validation.data.priority!,
      status: validation.data.status ?? 'Pending',
      dueDate: validation.data.dueDate!,
      userId: req.user.id,
    });

    emitTaskCreated(req.user.id, created);

    res.status(201).json({
      task: created,
      message: 'Task created successfully.',
    });
  } catch (err) {
    next(err);
  }
});

apiRouter.put(
  '/tasks/:id',
  authenticateJwt,
  authorizeTaskOwner,
  async (req: AuthenticatedRequest, res, next) => {
    try {
      if (!req.user || !req.taskResource) {
        res.status(401).json({ error: 'Authentication required.' });
        return;
      }

      const validation = validateTaskInput(req.body, true);
      if (!validation.ok || !validation.data) {
        res.status(400).json({ error: validation.error });
        return;
      }

      const updated = await updateTaskForUser(
        req.taskResource.id,
        req.user.id,
        validation.data,
      );

      if (!updated) {
        res.status(404).json({ error: 'Task not found.' });
        return;
      }

      emitTaskUpdated(req.user.id, updated);

      res.json({
        task: updated,
        message: 'Task updated successfully.',
      });
    } catch (err) {
      next(err);
    }
  },
);

apiRouter.delete(
  '/tasks/:id',
  authenticateJwt,
  authorizeTaskOwner,
  async (req: AuthenticatedRequest, res, next) => {
    try {
      if (!req.user || !req.taskResource) {
        res.status(401).json({ error: 'Authentication required.' });
        return;
      }

      const deleted = await deleteTaskForUser(req.taskResource.id, req.user.id);
      if (!deleted) {
        res.status(404).json({ error: 'Task not found.' });
        return;
      }

      emitTaskDeleted(req.user.id, req.taskResource.id);

      res.json({
        id: req.taskResource.id,
        message: 'Task deleted successfully.',
      });
    } catch (err) {
      next(err);
    }
  },
);

apiRouter.use((_req, res) => {
  res.status(404).json({ error: 'API endpoint not found.' });
});
