import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import mongoose, { Schema } from 'mongoose';
import type {
  PublicUser,
  TaskPriority,
  TaskRecord,
  TaskStatus,
  TasksStoreSnapshot,
  UserRecord,
} from './types.ts';

const DATA_DIR = path.resolve(process.cwd(), 'server', 'data');
const STORE_PATH = path.resolve(DATA_DIR, 'tasks-store.json');

export type DatabaseMode = 'mongodb' | 'local-store';

let activeMode: DatabaseMode = 'local-store';
let mongoConnected = false;

const UserSchema = new Schema<UserRecord>(
  {
    id: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    passwordHash: { type: String, required: true },
    createdAt: { type: String, required: true },
    updatedAt: { type: String, required: true },
  },
  { collection: 'users', versionKey: false },
);

const TaskSchema = new Schema<TaskRecord>(
  {
    id: { type: String, required: true, unique: true },
    title: { type: String, required: true },
    description: { type: String, default: '' },
    priority: { type: String, enum: ['High', 'Medium', 'Low'], required: true },
    status: { type: String, enum: ['Pending', 'Completed'], required: true },
    dueDate: { type: String, required: true },
    userId: { type: String, required: true, index: true },
    createdAt: { type: String, required: true },
    updatedAt: { type: String, required: true },
  },
  { collection: 'tasks', versionKey: false },
);

const UserModel = mongoose.models.User || mongoose.model<UserRecord>('User', UserSchema);
const TaskModel = mongoose.models.Task || mongoose.model<TaskRecord>('Task', TaskSchema);

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readLocalStore(): TasksStoreSnapshot {
  ensureDataDir();
  if (!fs.existsSync(STORE_PATH)) {
    const initial: TasksStoreSnapshot = { users: [], tasks: [] };
    fs.writeFileSync(STORE_PATH, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
  const raw = fs.readFileSync(STORE_PATH, 'utf-8');
  return JSON.parse(raw) as TasksStoreSnapshot;
}

function writeLocalStore(snapshot: TasksStoreSnapshot) {
  ensureDataDir();
  const tempPath = path.resolve(DATA_DIR, `tasks-store.${process.pid}.tmp.json`);
  fs.writeFileSync(tempPath, JSON.stringify(snapshot, null, 2), 'utf-8');
  fs.renameSync(tempPath, STORE_PATH);
}

function stripMongoInternal<T extends Record<string, unknown>>(doc: T): Omit<T, '_id'> {
  const copy = { ...doc };
  delete copy._id;
  return copy;
}

export function toPublicUser(user: UserRecord): PublicUser {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };
}

export function getDatabaseMode(): DatabaseMode {
  return activeMode;
}

export async function initDatabase(): Promise<void> {
  const uri = process.env.MONGODB_URI?.trim();
  if (uri && (uri.startsWith('mongodb://') || uri.startsWith('mongodb+srv://'))) {
    try {
      await mongoose.connect(uri, { serverSelectionTimeoutMS: 6000 });
      mongoConnected = true;
      activeMode = 'mongodb';
      console.log('Connected to MongoDB database (collections: users, tasks).');
      return;
    } catch (error) {
      console.warn(
        'MongoDB connection failed, falling back to local persistent JSON store:',
        error instanceof Error ? error.message : String(error),
      );
    }
  }

  activeMode = 'local-store';
  mongoConnected = false;
  readLocalStore();
  console.log(
    'Using local persistent datastore at server/data/tasks-store.json (set MONGODB_URI for MongoDB Atlas).',
  );
}

export async function findUserByEmail(email: string): Promise<UserRecord | null> {
  const normalized = email.trim().toLowerCase();
  if (mongoConnected) {
    const doc = await UserModel.findOne({ email: normalized }).lean();
    return doc
      ? (stripMongoInternal(doc as unknown as Record<string, unknown>) as unknown as UserRecord)
      : null;
  }
  return readLocalStore().users.find((u) => u.email === normalized) ?? null;
}

export async function findUserById(id: string): Promise<UserRecord | null> {
  if (mongoConnected) {
    const doc = await UserModel.findOne({ id }).lean();
    return doc
      ? (stripMongoInternal(doc as unknown as Record<string, unknown>) as unknown as UserRecord)
      : null;
  }
  return readLocalStore().users.find((u) => u.id === id) ?? null;
}

export async function createUser(input: {
  name: string;
  email: string;
  passwordHash: string;
}): Promise<UserRecord> {
  const now = new Date().toISOString();
  const user: UserRecord = {
    id: `usr-${crypto.randomUUID().slice(0, 12)}`,
    name: input.name,
    email: input.email.trim().toLowerCase(),
    passwordHash: input.passwordHash,
    createdAt: now,
    updatedAt: now,
  };
  if (mongoConnected) {
    await UserModel.create(user);
    return user;
  }
  const store = readLocalStore();
  store.users.push(user);
  writeLocalStore(store);
  return user;
}

export async function updateUserName(userId: string, name: string): Promise<UserRecord | null> {
  const now = new Date().toISOString();
  if (mongoConnected) {
    const updated = await UserModel.findOneAndUpdate(
      { id: userId },
      { $set: { name, updatedAt: now } },
      { new: true },
    ).lean();
    return updated
      ? (stripMongoInternal(updated as unknown as Record<string, unknown>) as unknown as UserRecord)
      : null;
  }
  const store = readLocalStore();
  const idx = store.users.findIndex((u) => u.id === userId);
  if (idx === -1) {
    return null;
  }
  store.users[idx] = { ...store.users[idx], name, updatedAt: now };
  writeLocalStore(store);
  return store.users[idx];
}

export interface TaskQueryOptions {
  status?: TaskStatus;
  priority?: TaskPriority;
  search?: string;
  sortBy?: 'dueDate' | 'createdAt';
  sortOrder?: 'asc' | 'desc';
}

export async function listTasksForUser(
  userId: string,
  options: TaskQueryOptions = {},
): Promise<TaskRecord[]> {
  let tasks: TaskRecord[];
  if (mongoConnected) {
    const query: Record<string, unknown> = { userId };
    if (options.status) {
      query.status = options.status;
    }
    if (options.priority) {
      query.priority = options.priority;
    }
    const docs = await TaskModel.find(query).lean();
    tasks = docs.map(
      (d) => stripMongoInternal(d as unknown as Record<string, unknown>) as unknown as TaskRecord,
    );
  } else {
    tasks = readLocalStore().tasks.filter((t) => {
      if (t.userId !== userId) return false;
      if (options.status && t.status !== options.status) return false;
      if (options.priority && t.priority !== options.priority) return false;
      return true;
    });
  }

  if (options.search) {
    const needle = options.search.toLowerCase();
    tasks = tasks.filter(
      (t) =>
        t.title.toLowerCase().includes(needle) ||
        t.description.toLowerCase().includes(needle),
    );
  }

  const sortBy = options.sortBy === 'createdAt' ? 'createdAt' : 'dueDate';
  const dir = options.sortOrder === 'desc' ? -1 : 1;

  return tasks.sort((a, b) => {
    const valA = a[sortBy];
    const valB = b[sortBy];
    if (valA < valB) return -1 * dir;
    if (valA > valB) return 1 * dir;
    return a.createdAt < b.createdAt ? 1 : -1;
  });
}

export async function findTaskById(taskId: string): Promise<TaskRecord | null> {
  if (mongoConnected) {
    const doc = await TaskModel.findOne({ id: taskId }).lean();
    return doc
      ? (stripMongoInternal(doc as unknown as Record<string, unknown>) as unknown as TaskRecord)
      : null;
  }
  return readLocalStore().tasks.find((t) => t.id === taskId) ?? null;
}

export async function createTask(input: {
  title: string;
  description: string;
  priority: TaskPriority;
  status: TaskStatus;
  dueDate: string;
  userId: string;
}): Promise<TaskRecord> {
  const now = new Date().toISOString();
  const task: TaskRecord = {
    id: `tsk-${crypto.randomUUID().slice(0, 12)}`,
    title: input.title,
    description: input.description,
    priority: input.priority,
    status: input.status,
    dueDate: input.dueDate,
    userId: input.userId,
    createdAt: now,
    updatedAt: now,
  };
  if (mongoConnected) {
    await TaskModel.create(task);
    return task;
  }
  const store = readLocalStore();
  store.tasks.unshift(task);
  writeLocalStore(store);
  return task;
}

export async function updateTaskForUser(
  taskId: string,
  userId: string,
  patch: Partial<Pick<TaskRecord, 'title' | 'description' | 'priority' | 'status' | 'dueDate'>>,
): Promise<TaskRecord | null> {
  const now = new Date().toISOString();
  if (mongoConnected) {
    const updated = await TaskModel.findOneAndUpdate(
      { id: taskId, userId },
      { $set: { ...patch, updatedAt: now } },
      { new: true },
    ).lean();
    return updated
      ? (stripMongoInternal(updated as unknown as Record<string, unknown>) as unknown as TaskRecord)
      : null;
  }
  const store = readLocalStore();
  const idx = store.tasks.findIndex((t) => t.id === taskId && t.userId === userId);
  if (idx === -1) {
    return null;
  }
  store.tasks[idx] = {
    ...store.tasks[idx],
    ...patch,
    updatedAt: now,
  };
  writeLocalStore(store);
  return store.tasks[idx];
}

export async function deleteTaskForUser(taskId: string, userId: string): Promise<boolean> {
  if (mongoConnected) {
    const res = await TaskModel.deleteOne({ id: taskId, userId });
    return res.deletedCount > 0;
  }
  const store = readLocalStore();
  const prevLen = store.tasks.length;
  store.tasks = store.tasks.filter((t) => !(t.id === taskId && t.userId === userId));
  if (store.tasks.length === prevLen) {
    return false;
  }
  writeLocalStore(store);
  return true;
}
