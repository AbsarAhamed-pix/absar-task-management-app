import type { TaskPriority, TaskStatus } from './types.ts';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const VALID_PRIORITIES = new Set<TaskPriority>(['High', 'Medium', 'Low']);
const VALID_STATUSES = new Set<TaskStatus>(['Pending', 'Completed']);

export function hasNoSqlOperatorKey(value: unknown): boolean {
  if (!value || typeof value !== 'object') {
    return false;
  }
  if (Array.isArray(value)) {
    return value.some((item) => hasNoSqlOperatorKey(item));
  }
  for (const [key, val] of Object.entries(value)) {
    if (key.startsWith('$') || key.includes('.')) {
      return true;
    }
    if (hasNoSqlOperatorKey(val)) {
      return true;
    }
  }
  return false;
}

export function cleanText(value: unknown, maxLength: number): string {
  if (typeof value !== 'string') {
    return '';
  }
  return value.trim().slice(0, maxLength);
}

export function validateRegisterInput(body: unknown): {
  ok: boolean;
  error?: string;
  data?: { name: string; email: string; password: string };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid registration payload.' };
  }
  const raw = body as Record<string, unknown>;
  const name = cleanText(raw.name, 80);
  const email = cleanText(raw.email, 150).toLowerCase();
  const password = typeof raw.password === 'string' ? raw.password : '';

  if (name.length < 2) {
    return { ok: false, error: 'Full name must be at least 2 characters.' };
  }
  if (!EMAIL_REGEX.test(email)) {
    return { ok: false, error: 'Please enter a valid email address.' };
  }
  if (password.length < 6 || password.length > 128) {
    return { ok: false, error: 'Password must be between 6 and 128 characters.' };
  }

  return { ok: true, data: { name, email, password } };
}

export function validateLoginInput(body: unknown): {
  ok: boolean;
  error?: string;
  data?: { email: string; password: string };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid login payload.' };
  }
  const raw = body as Record<string, unknown>;
  const email = cleanText(raw.email, 150).toLowerCase();
  const password = typeof raw.password === 'string' ? raw.password : '';

  if (!EMAIL_REGEX.test(email)) {
    return { ok: false, error: 'Please enter a valid email address.' };
  }
  if (!password) {
    return { ok: false, error: 'Password is required.' };
  }

  return { ok: true, data: { email, password } };
}

export function validateProfileUpdateInput(body: unknown): {
  ok: boolean;
  error?: string;
  data?: { name: string };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid profile payload.' };
  }
  const raw = body as Record<string, unknown>;
  const name = cleanText(raw.name, 80);
  if (name.length < 2) {
    return { ok: false, error: 'Display name must be at least 2 characters.' };
  }
  return { ok: true, data: { name } };
}

function isValidIsoDate(dateStr: string): boolean {
  if (!DATE_REGEX.test(dateStr)) {
    return false;
  }
  const parsed = new Date(`${dateStr}T00:00:00Z`);
  if (Number.isNaN(parsed.getTime())) {
    return false;
  }
  return parsed.toISOString().slice(0, 10) === dateStr;
}

export function validateTaskInput(
  body: unknown,
  isUpdate = false,
): {
  ok: boolean;
  error?: string;
  data?: {
    title?: string;
    description?: string;
    priority?: TaskPriority;
    status?: TaskStatus;
    dueDate?: string;
  };
} {
  if (!body || typeof body !== 'object' || Array.isArray(body) || hasNoSqlOperatorKey(body)) {
    return { ok: false, error: 'Invalid task payload.' };
  }
  const raw = body as Record<string, unknown>;
  const result: {
    title?: string;
    description?: string;
    priority?: TaskPriority;
    status?: TaskStatus;
    dueDate?: string;
  } = {};

  if (!isUpdate || raw.title !== undefined) {
    const title = cleanText(raw.title, 140);
    if (title.length < 2) {
      return { ok: false, error: 'Task title must be at least 2 characters.' };
    }
    result.title = title;
  }

  if (!isUpdate || raw.description !== undefined) {
    result.description = cleanText(raw.description, 2000);
  }

  if (!isUpdate || raw.priority !== undefined) {
    const priority = cleanText(raw.priority, 20) as TaskPriority;
    if (!VALID_PRIORITIES.has(priority)) {
      return { ok: false, error: 'Priority must be High, Medium, or Low.' };
    }
    result.priority = priority;
  }

  if (raw.status !== undefined) {
    const status = cleanText(raw.status, 20) as TaskStatus;
    if (!VALID_STATUSES.has(status)) {
      return { ok: false, error: 'Status must be Pending or Completed.' };
    }
    result.status = status;
  } else if (!isUpdate) {
    result.status = 'Pending';
  }

  if (!isUpdate || raw.dueDate !== undefined) {
    const dueDate = cleanText(raw.dueDate, 20);
    if (!isValidIsoDate(dueDate)) {
      return { ok: false, error: 'Due date must be a valid date in YYYY-MM-DD format.' };
    }
    result.dueDate = dueDate;
  }

  return { ok: true, data: result };
}
