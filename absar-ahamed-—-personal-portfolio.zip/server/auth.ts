import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { findTaskById, findUserById, toPublicUser } from './db.ts';
import type { PublicUser, TaskRecord } from './types.ts';

const JWT_SECRET =
  process.env.JWT_SECRET?.trim() || crypto.randomBytes(32).toString('hex');

const JWT_EXPIRES_IN = '24h';

export interface AuthenticatedRequest extends Request {
  user?: PublicUser;
  taskResource?: TaskRecord;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, passwordHash: string): Promise<boolean> {
  return bcrypt.compare(password, passwordHash);
}

export function signJwtToken(user: PublicUser): string {
  return jwt.sign(
    { sub: user.id, email: user.email },
    JWT_SECRET,
    { algorithm: 'HS256', expiresIn: JWT_EXPIRES_IN },
  );
}

export function verifyJwtToken(token: string): { sub: string; email: string } | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET, { algorithms: ['HS256'] });
    if (
      decoded &&
      typeof decoded === 'object' &&
      typeof decoded.sub === 'string' &&
      typeof decoded.email === 'string'
    ) {
      return { sub: decoded.sub, email: decoded.email };
    }
    return null;
  } catch {
    return null;
  }
}

export async function authenticateJwt(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }

  const token = header.slice('Bearer '.length).trim();
  const payload = verifyJwtToken(token);
  if (!payload) {
    res.status(401).json({ error: 'Invalid or expired session token. Please sign in again.' });
    return;
  }

  const user = await findUserById(payload.sub);
  if (!user) {
    res.status(401).json({ error: 'User account not found.' });
    return;
  }

  req.user = toPublicUser(user);
  next();
}

export async function authorizeTaskOwner(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> {
  if (!req.user) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }

  const taskId = typeof req.params.id === 'string' ? req.params.id.trim() : '';
  if (!taskId) {
    res.status(400).json({ error: 'Valid task ID is required.' });
    return;
  }

  const task = await findTaskById(taskId);
  if (!task) {
    res.status(404).json({ error: 'Task not found.' });
    return;
  }

  if (task.userId !== req.user.id) {
    res.status(403).json({ error: 'Access denied: you are not authorized to access this task.' });
    return;
  }

  req.taskResource = task;
  next();
}
