import type { Server as HttpServer } from 'node:http';
import { Server as SocketIOServer } from 'socket.io';
import { verifyJwtToken } from './auth.ts';
import type { TaskRecord } from './types.ts';

let io: SocketIOServer | null = null;

export function initRealtimeServer(httpServer: HttpServer): SocketIOServer {
  io = new SocketIOServer(httpServer, {
    path: '/socket.io',
    cors: {
      origin: (origin, callback) => {
        if (!origin) {
          callback(null, true);
          return;
        }
        const appUrl = process.env.APP_URL?.trim();
        if (
          origin.startsWith('http://localhost:') ||
          origin.startsWith('http://127.0.0.1:') ||
          (appUrl && origin === appUrl) ||
          origin.endsWith('.run.app')
        ) {
          callback(null, true);
          return;
        }
        callback(null, false);
      },
      methods: ['GET', 'POST'],
    },
  });

  io.use((socket, next) => {
    const token =
      typeof socket.handshake.auth?.token === 'string'
        ? socket.handshake.auth.token
        : '';
    if (!token) {
      next(new Error('Authentication required for real-time updates.'));
      return;
    }
    const payload = verifyJwtToken(token);
    if (!payload) {
      next(new Error('Invalid or expired session token.'));
      return;
    }
    socket.data.userId = payload.sub;
    next();
  });

  io.on('connection', (socket) => {
    const userId = typeof socket.data.userId === 'string' ? socket.data.userId : '';
    if (userId) {
      socket.join(`user:${userId}`);
    }
  });

  return io;
}

export function isRealtimeActive(): boolean {
  return io !== null;
}

export function emitTaskCreated(userId: string, task: TaskRecord): void {
  io?.to(`user:${userId}`).emit('task:created', { task });
}

export function emitTaskUpdated(userId: string, task: TaskRecord): void {
  io?.to(`user:${userId}`).emit('task:updated', { task });
}

export function emitTaskDeleted(userId: string, taskId: string): void {
  io?.to(`user:${userId}`).emit('task:deleted', { taskId });
}
