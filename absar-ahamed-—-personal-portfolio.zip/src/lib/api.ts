import type { TaskItem, TaskPriority, TaskStats, TaskStatus, UserProfile } from '../types';

async function parseJsonResponse<T>(res: Response): Promise<T> {
  const payload = await res.json().catch(() => ({}));
  if (!res.ok) {
    const message =
      typeof (payload as { error?: unknown }).error === 'string'
        ? (payload as { error: string }).error
        : `Request failed with status ${res.status}`;
    throw new Error(message);
  }
  return payload as T;
}

export async function registerUser(input: {
  name: string;
  email: string;
  password: string;
}): Promise<{ token: string; user: UserProfile; message: string }> {
  const res = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
  return parseJsonResponse<{ token: string; user: UserProfile; message: string }>(res);
}

export async function loginUser(input: {
  email: string;
  password: string;
}): Promise<{ token: string; user: UserProfile; message: string }> {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
  return parseJsonResponse<{ token: string; user: UserProfile; message: string }>(res);
}

export async function logoutUser(token: string): Promise<void> {
  await fetch('/api/auth/logout', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
  }).catch(() => undefined);
}

export async function fetchUserProfile(
  token: string,
): Promise<{ user: UserProfile; stats: TaskStats }> {
  const res = await fetch('/api/auth/profile', {
    headers: { Authorization: `Bearer ${token}` },
  });
  return parseJsonResponse<{ user: UserProfile; stats: TaskStats }>(res);
}

export async function updateUserProfile(
  name: string,
  token: string,
): Promise<{ user: UserProfile; message: string }> {
  const res = await fetch('/api/auth/profile', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ name }),
  });
  return parseJsonResponse<{ user: UserProfile; message: string }>(res);
}

export interface FetchTasksParams {
  status?: 'All' | TaskStatus;
  priority?: 'All' | TaskPriority;
  search?: string;
  sortBy?: 'dueDate' | 'createdAt';
  sortOrder?: 'asc' | 'desc';
}

export async function fetchTasks(
  token: string,
  params: FetchTasksParams = {},
): Promise<{ tasks: TaskItem[]; stats: TaskStats }> {
  const query = new URLSearchParams();
  if (params.status && params.status !== 'All') {
    query.set('status', params.status);
  }
  if (params.priority && params.priority !== 'All') {
    query.set('priority', params.priority);
  }
  if (params.search && params.search.trim()) {
    query.set('search', params.search.trim());
  }
  if (params.sortBy) {
    query.set('sortBy', params.sortBy);
  }
  if (params.sortOrder) {
    query.set('sortOrder', params.sortOrder);
  }
  const qs = query.toString();
  const res = await fetch(`/api/tasks${qs ? `?${qs}` : ''}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return parseJsonResponse<{ tasks: TaskItem[]; stats: TaskStats }>(res);
}

export interface TaskPayload {
  title: string;
  description: string;
  priority: TaskPriority;
  status?: TaskStatus;
  dueDate: string;
}

export async function createTask(
  payload: TaskPayload,
  token: string,
): Promise<{ task: TaskItem; message: string }> {
  const res = await fetch('/api/tasks', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });
  return parseJsonResponse<{ task: TaskItem; message: string }>(res);
}

export async function updateTask(
  id: string,
  payload: Partial<TaskPayload>,
  token: string,
): Promise<{ task: TaskItem; message: string }> {
  const res = await fetch(`/api/tasks/${encodeURIComponent(id)}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });
  return parseJsonResponse<{ task: TaskItem; message: string }>(res);
}

export async function deleteTask(
  id: string,
  token: string,
): Promise<{ id: string; message: string }> {
  const res = await fetch(`/api/tasks/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
  return parseJsonResponse<{ id: string; message: string }>(res);
}
