import { useCallback, useEffect, useMemo, useState } from 'react';
import { Menu, Moon, Plus, Sun } from 'lucide-react';
import { io, type Socket } from 'socket.io-client';
import { AuthScreen } from './components/AuthScreen';
import { DashboardView } from './components/DashboardView';
import { ProfileView } from './components/ProfileView';
import { Sidebar } from './components/Sidebar';
import {
  DeleteConfirmModal,
  TaskDetailModal,
  TaskFormModal,
} from './components/TaskModals';
import { TasksView } from './components/TasksView';
import {
  createTask,
  deleteTask,
  fetchTasks,
  logoutUser,
  updateTask,
  type TaskPayload,
} from './lib/api';
import type {
  TaskItem,
  TaskPriority,
  TaskStats,
  TaskStatus,
  UserProfile,
  WorkspaceView,
} from './types';

const EMPTY_STATS: TaskStats = {
  total: 0,
  pending: 0,
  completed: 0,
  overdue: 0,
  highPriority: 0,
  mediumPriority: 0,
  lowPriority: 0,
};

function computeClientStats(list: TaskItem[]): TaskStats {
  const todayIso = new Date().toISOString().slice(0, 10);
  let pending = 0;
  let completed = 0;
  let overdue = 0;
  let highPriority = 0;
  let mediumPriority = 0;
  let lowPriority = 0;

  for (const t of list) {
    if (t.status === 'Completed') {
      completed += 1;
    } else {
      pending += 1;
      if (t.dueDate < todayIso) {
        overdue += 1;
      }
    }
    if (t.priority === 'High') highPriority += 1;
    else if (t.priority === 'Medium') mediumPriority += 1;
    else lowPriority += 1;
  }

  return {
    total: list.length,
    pending,
    completed,
    overdue,
    highPriority,
    mediumPriority,
    lowPriority,
  };
}

export default function App() {
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('taskflow-theme');
      if (saved === 'dark' || saved === 'light') return saved;
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return 'light';
  });

  // JWT stored strictly in React memory for session security
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);

  const [allTasks, setAllTasks] = useState<TaskItem[]>([]);
  const [tasksLoading, setTasksLoading] = useState(false);
  const [tasksError, setTasksError] = useState<string | null>(null);

  // Navigation & Filters
  const [activeView, setActiveView] = useState<WorkspaceView>('dashboard');
  const [statusFilter, setStatusFilter] = useState<'All' | TaskStatus>('All');
  const [priorityFilter, setPriorityFilter] = useState<'All' | TaskPriority>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'dueDate' | 'createdAt'>('dueDate');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Modals
  const [formOpen, setFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null);
  const [formSaving, setFormSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [viewingTask, setViewingTask] = useState<TaskItem | null>(null);
  const [deletingTask, setDeletingTask] = useState<TaskItem | null>(null);
  const [deletingBusy, setDeletingBusy] = useState(false);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('taskflow-theme', theme);
  }, [theme]);

  const handleLogout = useCallback(async () => {
    if (authToken) {
      await logoutUser(authToken);
    }
    setAuthToken(null);
    setCurrentUser(null);
    setAllTasks([]);
    setActiveView('dashboard');
    setStatusFilter('All');
    setPriorityFilter('All');
    setSearchQuery('');
  }, [authToken]);

  const loadTasks = useCallback(async () => {
    if (!authToken) return;
    setTasksLoading(true);
    setTasksError(null);
    try {
      const res = await fetchTasks(authToken, { sortBy: 'dueDate', sortOrder: 'asc' });
      setAllTasks(res.tasks);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load tasks.';
      if (message.toLowerCase().includes('session') || message.toLowerCase().includes('sign in')) {
        setAuthToken(null);
        setCurrentUser(null);
        return;
      }
      setTasksError(message);
    } finally {
      setTasksLoading(false);
    }
  }, [authToken]);

  useEffect(() => {
    if (authToken) {
      loadTasks();
    }
  }, [authToken, loadTasks]);

  // Real-time Socket.IO synchronization scoped to authenticated user
  useEffect(() => {
    if (!authToken) return;

    const socket: Socket = io({
      path: '/socket.io',
      auth: { token: authToken },
      transports: ['websocket', 'polling'],
      reconnection: true,
    });

    socket.on('task:created', ({ task }: { task: TaskItem }) => {
      setAllTasks((prev) => {
        if (prev.some((item) => item.id === task.id)) {
          return prev;
        }
        return [task, ...prev];
      });
    });

    socket.on('task:updated', ({ task }: { task: TaskItem }) => {
      setAllTasks((prev) => prev.map((item) => (item.id === task.id ? task : item)));
      setViewingTask((prev) => (prev && prev.id === task.id ? task : prev));
    });

    socket.on('task:deleted', ({ taskId }: { taskId: string }) => {
      setAllTasks((prev) => prev.filter((item) => item.id !== taskId));
      setViewingTask((prev) => (prev && prev.id === taskId ? null : prev));
    });

    socket.on('connect', () => {
      loadTasks();
    });

    return () => {
      socket.disconnect();
    };
  }, [authToken, loadTasks]);

  const stats = useMemo(() => {
    if (!authToken) return EMPTY_STATS;
    return computeClientStats(allTasks);
  }, [authToken, allTasks]);

  const visibleTasks = useMemo(() => {
    const filtered = allTasks.filter((task) => {
      if (statusFilter !== 'All' && task.status !== statusFilter) return false;
      if (priorityFilter !== 'All' && task.priority !== priorityFilter) return false;
      if (searchQuery.trim()) {
        const needle = searchQuery.trim().toLowerCase();
        const hitTitle = task.title.toLowerCase().includes(needle);
        const hitDesc = task.description.toLowerCase().includes(needle);
        if (!hitTitle && !hitDesc) return false;
      }
      return true;
    });

    const dir = sortOrder === 'desc' ? -1 : 1;
    return [...filtered].sort((a, b) => {
      const valA = a[sortBy];
      const valB = b[sortBy];
      if (valA < valB) return -1 * dir;
      if (valA > valB) return 1 * dir;
      return a.createdAt < b.createdAt ? 1 : -1;
    });
  }, [allTasks, statusFilter, priorityFilter, searchQuery, sortBy, sortOrder]);

  function handleSelectView(view: WorkspaceView, priority: 'All' | TaskPriority = 'All') {
    setActiveView(view);
    setPriorityFilter(priority);
    if (view === 'pending') {
      setStatusFilter('Pending');
    } else if (view === 'completed') {
      setStatusFilter('Completed');
    } else if (view === 'all') {
      setStatusFilter('All');
    }
  }

  function openCreateModal() {
    setEditingTask(null);
    setFormError(null);
    setFormOpen(true);
  }

  function openEditModal(task: TaskItem) {
    setEditingTask(task);
    setFormError(null);
    setFormOpen(true);
  }

  async function handleSaveTask(payload: TaskPayload) {
    if (!authToken) return;
    setFormSaving(true);
    setFormError(null);
    try {
      if (editingTask) {
        const res = await updateTask(editingTask.id, payload, authToken);
        setAllTasks((prev) => prev.map((t) => (t.id === res.task.id ? res.task : t)));
      } else {
        const res = await createTask(payload, authToken);
        setAllTasks((prev) =>
          prev.some((t) => t.id === res.task.id) ? prev : [res.task, ...prev],
        );
      }
      setFormOpen(false);
      setEditingTask(null);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Unable to save task.');
    } finally {
      setFormSaving(false);
    }
  }

  async function handleToggleStatus(task: TaskItem) {
    if (!authToken) return;
    const nextStatus: TaskStatus = task.status === 'Completed' ? 'Pending' : 'Completed';
    try {
      const res = await updateTask(task.id, { status: nextStatus }, authToken);
      setAllTasks((prev) => prev.map((t) => (t.id === res.task.id ? res.task : t)));
    } catch (err) {
      setTasksError(err instanceof Error ? err.message : 'Unable to update task status.');
    }
  }

  async function handleConfirmDelete() {
    if (!authToken || !deletingTask) return;
    setDeletingBusy(true);
    try {
      await deleteTask(deletingTask.id, authToken);
      setAllTasks((prev) => prev.filter((t) => t.id !== deletingTask.id));
      setDeletingTask(null);
    } catch (err) {
      setTasksError(err instanceof Error ? err.message : 'Unable to delete task.');
    } finally {
      setDeletingBusy(false);
    }
  }

  if (!authToken || !currentUser) {
    return (
      <AuthScreen
        theme={theme}
        onToggleTheme={() => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'))}
        onAuthenticated={(token, user) => {
          setAuthToken(token);
          setCurrentUser(user);
        }}
      />
    );
  }

  const viewTitleMap: Record<WorkspaceView, string> = {
    dashboard: 'Dashboard',
    all: priorityFilter !== 'All' ? `${priorityFilter} Priority Tasks` : 'All Tasks',
    pending: 'Pending Tasks',
    completed: 'Completed Tasks',
    profile: 'User Profile',
  };

  return (
    <div className="min-h-screen flex bg-[#F8FAFC] text-[#0F172A] dark:bg-[#09090B] dark:text-[#F4F4F5] transition-colors duration-150">
      <Sidebar
        user={currentUser}
        stats={stats}
        activeView={activeView}
        activePriority={priorityFilter}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
        onSelectView={handleSelectView}
        onLogout={handleLogout}
      />

      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar Contract: Breadcrumb on Left, Theme + Primary CTA on Right */}
        <header className="sticky top-0 z-30 h-16 border-b border-slate-200 dark:border-zinc-800 bg-white/90 dark:bg-[#0C0C0E]/90 backdrop-blur-md">
          <div className="flex h-full items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setMobileSidebarOpen(true)}
                aria-label="Open navigation sidebar"
                className="lg:hidden inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-slate-200 dark:border-zinc-800 text-slate-700 dark:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-900 cursor-pointer"
              >
                <Menu className="h-5 w-5" />
              </button>

              <div className="flex items-center gap-2 text-sm min-w-0">
                <span className="text-slate-400 dark:text-zinc-500 hidden sm:inline whitespace-nowrap">
                  Workspace
                </span>
                <span className="text-slate-300 dark:text-zinc-700 hidden sm:inline">/</span>
                <span className="font-display font-semibold text-slate-950 dark:text-zinc-50 truncate">
                  {viewTitleMap[activeView]}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'))}
                aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
                className="inline-flex h-10 items-center gap-2 rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-900 px-3 text-xs font-medium text-slate-700 dark:text-zinc-200 hover:border-slate-300 dark:hover:border-zinc-700 cursor-pointer whitespace-nowrap shrink-0"
              >
                {theme === 'dark' ? (
                  <>
                    <Sun className="h-3.5 w-3.5 text-amber-500" />
                    <span className="hidden sm:inline">Light</span>
                  </>
                ) : (
                  <>
                    <Moon className="h-3.5 w-3.5 text-blue-600" />
                    <span className="hidden sm:inline">Dark</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={openCreateModal}
                className="inline-flex h-10 items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 text-xs font-semibold text-white hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>New Task</span>
              </button>
            </div>
          </div>
        </header>

        {/* Main Workspace Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl w-full mx-auto">
          {activeView === 'dashboard' && (
            <DashboardView
              user={currentUser}
              tasks={allTasks}
              stats={stats}
              loading={tasksLoading}
              onCreateTask={openCreateModal}
              onToggleStatus={handleToggleStatus}
              onViewTask={setViewingTask}
              onEditTask={openEditModal}
              onDeleteTask={setDeletingTask}
              onOpenAllTasks={() => handleSelectView('all', 'All')}
            />
          )}

          {(activeView === 'all' || activeView === 'pending' || activeView === 'completed') && (
            <TasksView
              heading={viewTitleMap[activeView]}
              tasks={visibleTasks}
              loading={tasksLoading}
              error={tasksError}
              statusFilter={statusFilter}
              priorityFilter={priorityFilter}
              searchQuery={searchQuery}
              sortBy={sortBy}
              sortOrder={sortOrder}
              onStatusFilterChange={(nextStatus) => {
                setStatusFilter(nextStatus);
                if (nextStatus === 'Pending') setActiveView('pending');
                else if (nextStatus === 'Completed') setActiveView('completed');
                else setActiveView('all');
              }}
              onPriorityFilterChange={setPriorityFilter}
              onSearchChange={setSearchQuery}
              onSortChange={(nextBy, nextOrder) => {
                setSortBy(nextBy);
                setSortOrder(nextOrder);
              }}
              onRetry={loadTasks}
              onCreateTask={openCreateModal}
              onViewTask={setViewingTask}
              onEditTask={openEditModal}
              onDeleteTask={setDeletingTask}
              onToggleStatus={handleToggleStatus}
            />
          )}

          {activeView === 'profile' && (
            <ProfileView
              user={currentUser}
              stats={stats}
              token={authToken}
              onUserUpdated={setCurrentUser}
            />
          )}
        </main>
      </div>

      {/* Modals */}
      <TaskFormModal
        open={formOpen}
        editingTask={editingTask}
        saving={formSaving}
        error={formError}
        onSave={handleSaveTask}
        onClose={() => {
          setFormOpen(false);
          setEditingTask(null);
        }}
      />

      <TaskDetailModal
        task={viewingTask}
        onClose={() => setViewingTask(null)}
        onEdit={openEditModal}
        onDelete={setDeletingTask}
      />

      <DeleteConfirmModal
        task={deletingTask}
        deleting={deletingBusy}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeletingTask(null)}
      />
    </div>
  );
}
