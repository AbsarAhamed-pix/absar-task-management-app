import {
  AlertTriangle,
  ArrowRight,
  Calendar,
  CheckCircle2,
  Clock,
  ListChecks,
  Plus,
  Trash2,
} from 'lucide-react';
import type { TaskItem, TaskStats, UserProfile } from '../types';

interface DashboardViewProps {
  user: UserProfile;
  tasks: TaskItem[];
  stats: TaskStats;
  loading: boolean;
  onCreateTask: () => void;
  onToggleStatus: (task: TaskItem) => void;
  onViewTask: (task: TaskItem) => void;
  onEditTask: (task: TaskItem) => void;
  onDeleteTask: (task: TaskItem) => void;
  onOpenAllTasks: () => void;
}

export function DashboardView({
  user,
  tasks,
  stats,
  loading,
  onCreateTask,
  onToggleStatus,
  onViewTask,
  onEditTask,
  onDeleteTask,
  onOpenAllTasks,
}: DashboardViewProps) {
  const todayIso = new Date().toISOString().slice(0, 10);
  const completionRate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;
  const recentTasks = [...tasks]
    .sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1))
    .slice(0, 5);

  const kpis = [
    {
      label: 'Total Tasks',
      value: stats.total,
      note: 'Across all priorities',
      icon: ListChecks,
      valueClass: 'text-slate-950 dark:text-zinc-50',
      iconClass: 'text-blue-600 dark:text-blue-400',
    },
    {
      label: 'Pending Tasks',
      value: stats.pending,
      note: 'Active work remaining',
      icon: Clock,
      valueClass: 'text-amber-700 dark:text-amber-400',
      iconClass: 'text-amber-600 dark:text-amber-400',
    },
    {
      label: 'Completed Tasks',
      value: stats.completed,
      note: `${completionRate}% completion rate`,
      icon: CheckCircle2,
      valueClass: 'text-emerald-700 dark:text-emerald-400',
      iconClass: 'text-emerald-600 dark:text-emerald-400',
    },
    {
      label: 'Overdue Tasks',
      value: stats.overdue,
      note: 'Past due date & pending',
      icon: AlertTriangle,
      valueClass: stats.overdue > 0 ? 'text-red-700 dark:text-red-400' : 'text-slate-950 dark:text-zinc-50',
      iconClass: stats.overdue > 0 ? 'text-red-600 dark:text-red-400' : 'text-slate-400 dark:text-zinc-500',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-950 dark:text-zinc-50">
            Welcome back, {user.name}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-zinc-400">
            Overview of your personal tasks, deadlines, and priority breakdown.
          </p>
        </div>

        <button
          type="button"
          onClick={onCreateTask}
          className="inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          <span>Create New Task</span>
        </button>
      </div>

      {/* 4 KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div
              key={kpi.label}
              className="rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-5"
            >
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs font-medium text-slate-500 dark:text-zinc-400">
                  {kpi.label}
                </p>
                <Icon className={`h-4 w-4 ${kpi.iconClass}`} />
              </div>
              <p className={`mt-3 font-mono text-3xl font-semibold tabular-nums ${kpi.valueClass}`}>
                {kpi.value}
              </p>
              <p className="mt-1.5 text-xs text-slate-500 dark:text-zinc-400 tabular-nums">
                {kpi.note}
              </p>
            </div>
          );
        })}
      </div>

      {/* Task Statistics & Recent Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Task Statistics Panel */}
        <section className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-6 space-y-6">
          <div>
            <h2 className="font-display text-base font-bold text-slate-950 dark:text-zinc-50">
              Task Statistics
            </h2>
            <p className="mt-1 text-xs text-slate-500 dark:text-zinc-400">
              Live breakdown calculated from your saved tasks.
            </p>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs font-medium mb-2">
              <span className="text-slate-700 dark:text-zinc-300">Overall Completion</span>
              <span className="font-mono tabular-nums text-slate-950 dark:text-zinc-50">
                {completionRate}%
              </span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-md bg-slate-100 dark:bg-zinc-800">
              <div
                className="h-full bg-emerald-600 dark:bg-emerald-500 transition-all duration-300"
                style={{ width: `${completionRate}%` }}
              />
            </div>
          </div>

          <div className="space-y-3 pt-4 border-t border-slate-200 dark:border-zinc-800">
            <p className="text-xs font-semibold text-slate-500 dark:text-zinc-400">
              By Priority Level
            </p>
            {(
              [
                {
                  label: 'High Priority',
                  count: stats.highPriority,
                  barColor: 'bg-red-600 dark:bg-red-500',
                  textColor: 'text-red-700 dark:text-red-400',
                },
                {
                  label: 'Medium Priority',
                  count: stats.mediumPriority,
                  barColor: 'bg-amber-500',
                  textColor: 'text-amber-700 dark:text-amber-400',
                },
                {
                  label: 'Low Priority',
                  count: stats.lowPriority,
                  barColor: 'bg-emerald-600 dark:bg-emerald-500',
                  textColor: 'text-emerald-700 dark:text-emerald-400',
                },
              ] as const
            ).map((row) => {
              const pct = stats.total > 0 ? Math.round((row.count / stats.total) * 100) : 0;
              return (
                <div key={row.label} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className={`font-medium ${row.textColor}`}>{row.label}</span>
                    <span className="font-mono tabular-nums text-slate-600 dark:text-zinc-400">
                      {row.count} ({pct}%)
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-sm bg-slate-100 dark:bg-zinc-800">
                    <div
                      className={`h-full ${row.barColor}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Recent Tasks Panel */}
        <section className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-6">
          <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-zinc-800">
            <div>
              <h2 className="font-display text-base font-bold text-slate-950 dark:text-zinc-50">
                Recent Tasks
              </h2>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-zinc-400">
                Your most recently created or updated tasks.
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenAllTasks}
              className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer whitespace-nowrap"
            >
              <span>View All</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {loading ? (
            <div className="py-6 space-y-3">
              {[1, 2, 3].map((row) => (
                <div
                  key={row}
                  className="h-12 w-full rounded-lg bg-slate-100 dark:bg-zinc-800/70 animate-pulse"
                />
              ))}
            </div>
          ) : recentTasks.length === 0 ? (
            <div className="py-12 text-center">
              <p className="font-display text-base font-semibold text-slate-900 dark:text-zinc-100">
                No tasks created yet
              </p>
              <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
                Create your first task to start tracking deadlines and completion progress.
              </p>
              <button
                type="button"
                onClick={onCreateTask}
                className="mt-4 inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 transition-colors cursor-pointer"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Create First Task</span>
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-200/80 dark:divide-zinc-800/80">
              {recentTasks.map((task) => {
                const isOverdue = task.status === 'Pending' && task.dueDate < todayIso;
                return (
                  <div
                    key={task.id}
                    className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="min-w-0 flex items-start gap-3">
                      <button
                        type="button"
                        onClick={() => onToggleStatus(task)}
                        aria-label={
                          task.status === 'Completed'
                            ? `Mark ${task.title} as pending`
                            : `Mark ${task.title} as completed`
                        }
                        className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border transition-colors cursor-pointer ${
                          task.status === 'Completed'
                            ? 'border-emerald-600 bg-emerald-600 text-white'
                            : 'border-slate-300 dark:border-zinc-600 hover:border-blue-600'
                        }`}
                      >
                        {task.status === 'Completed' && <CheckCircle2 className="h-3.5 w-3.5" />}
                      </button>

                      <div className="min-w-0">
                        <button
                          type="button"
                          onClick={() => onViewTask(task)}
                          className={`text-left text-sm font-semibold hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer truncate block max-w-full ${
                            task.status === 'Completed'
                              ? 'line-through text-slate-400 dark:text-zinc-500'
                              : 'text-slate-900 dark:text-zinc-100'
                          }`}
                        >
                          {task.title}
                        </button>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-zinc-400">
                          <span
                            className={
                              task.priority === 'High'
                                ? 'font-medium text-red-600 dark:text-red-400'
                                : task.priority === 'Medium'
                                  ? 'font-medium text-amber-600 dark:text-amber-400'
                                  : 'font-medium text-emerald-600 dark:text-emerald-400'
                            }
                          >
                            {task.priority} Priority
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1 font-mono tabular-nums">
                            <Calendar className="h-3 w-3" />
                            {task.dueDate}
                          </span>
                          {isOverdue && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="font-semibold text-red-600 dark:text-red-400">
                                Overdue
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pl-8 sm:pl-0 shrink-0">
                      <button
                        type="button"
                        onClick={() => onEditTask(task)}
                        className="rounded-md border border-slate-200 dark:border-zinc-700 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-zinc-200 hover:border-blue-600 cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteTask(task)}
                        aria-label={`Delete ${task.title}`}
                        className="rounded-md border border-red-200 dark:border-red-900/60 p-1.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
