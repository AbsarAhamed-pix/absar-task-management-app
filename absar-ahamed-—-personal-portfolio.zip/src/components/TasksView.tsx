import {
  AlertCircle,
  Calendar,
  CheckCircle2,
  Clock,
  Pencil,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import type { TaskItem, TaskPriority, TaskStatus } from '../types';

interface TasksViewProps {
  heading: string;
  tasks: TaskItem[];
  loading: boolean;
  error: string | null;
  statusFilter: 'All' | TaskStatus;
  priorityFilter: 'All' | TaskPriority;
  searchQuery: string;
  sortOrder: 'asc' | 'desc';
  sortBy: 'dueDate' | 'createdAt';
  onStatusFilterChange: (status: 'All' | TaskStatus) => void;
  onPriorityFilterChange: (priority: 'All' | TaskPriority) => void;
  onSearchChange: (value: string) => void;
  onSortChange: (sortBy: 'dueDate' | 'createdAt', sortOrder: 'asc' | 'desc') => void;
  onRetry: () => void;
  onCreateTask: () => void;
  onViewTask: (task: TaskItem) => void;
  onEditTask: (task: TaskItem) => void;
  onDeleteTask: (task: TaskItem) => void;
  onToggleStatus: (task: TaskItem) => void;
}

export function TasksView({
  heading,
  tasks,
  loading,
  error,
  statusFilter,
  priorityFilter,
  searchQuery,
  sortOrder,
  sortBy,
  onStatusFilterChange,
  onPriorityFilterChange,
  onSearchChange,
  onSortChange,
  onRetry,
  onCreateTask,
  onViewTask,
  onEditTask,
  onDeleteTask,
  onToggleStatus,
}: TasksViewProps) {
  const todayIso = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-950 dark:text-zinc-50">
            {heading}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-zinc-400">
            Search, filter by status or priority, sort by due date, and manage your tasks.
          </p>
        </div>

        <button
          type="button"
          onClick={onCreateTask}
          className="inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          <span>New Task</span>
        </button>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search Input */}
          <div className="md:col-span-5 relative">
            <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search tasks by title or description..."
              aria-label="Search tasks"
              className="w-full min-h-[40px] rounded-lg border border-slate-300 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-950 pl-9 pr-3 py-2 text-sm text-slate-950 dark:text-zinc-100 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
            />
          </div>

          {/* Segmented Status Filter */}
          <div className="md:col-span-3 flex items-center gap-1 rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-950 p-1">
            {(['All', 'Pending', 'Completed'] as const).map((status) => (
              <button
                key={status}
                type="button"
                onClick={() => onStatusFilterChange(status)}
                className={`flex-1 min-h-[32px] rounded-md px-2 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                  statusFilter === status
                    ? 'bg-slate-950 dark:bg-zinc-100 text-white dark:text-zinc-950'
                    : 'text-slate-600 dark:text-zinc-400 hover:text-slate-950 dark:hover:text-zinc-100'
                }`}
              >
                {status}
              </button>
            ))}
          </div>

          {/* Priority Select */}
          <div className="md:col-span-2">
            <select
              aria-label="Filter by priority"
              value={priorityFilter}
              onChange={(e) => onPriorityFilterChange(e.target.value as 'All' | TaskPriority)}
              className="w-full min-h-[40px] rounded-lg border border-slate-300 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-950 px-3 py-2 text-xs font-medium text-slate-900 dark:text-zinc-100 focus:border-blue-600 focus:outline-none"
            >
              <option value="All">All Priorities</option>
              <option value="High">High Priority</option>
              <option value="Medium">Medium Priority</option>
              <option value="Low">Low Priority</option>
            </select>
          </div>

          {/* Sort Select */}
          <div className="md:col-span-2">
            <select
              aria-label="Sort tasks"
              value={`${sortBy}:${sortOrder}`}
              onChange={(e) => {
                const [by, order] = e.target.value.split(':') as [
                  'dueDate' | 'createdAt',
                  'asc' | 'desc',
                ];
                onSortChange(by, order);
              }}
              className="w-full min-h-[40px] rounded-lg border border-slate-300 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-950 px-3 py-2 text-xs font-medium text-slate-900 dark:text-zinc-100 focus:border-blue-600 focus:outline-none"
            >
              <option value="dueDate:asc">Due Date (Earliest)</option>
              <option value="dueDate:desc">Due Date (Latest)</option>
              <option value="createdAt:desc">Newest Created</option>
            </select>
          </div>
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((skeleton) => (
            <div
              key={skeleton}
              className="h-44 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-5 animate-pulse"
            >
              <div className="h-4 w-1/3 rounded bg-slate-200 dark:bg-zinc-800" />
              <div className="mt-3 h-5 w-3/4 rounded bg-slate-200 dark:bg-zinc-800" />
              <div className="mt-3 h-10 w-full rounded bg-slate-200 dark:bg-zinc-800" />
            </div>
          ))}
        </div>
      )}

      {/* Error State */}
      {!loading && error && (
        <div className="rounded-xl border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/30 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-2.5 text-red-900 dark:text-red-200">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold">Unable to load tasks</p>
              <p className="text-xs mt-0.5">{error}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onRetry}
            className="rounded-lg bg-red-700 px-4 py-2 text-xs font-semibold text-white hover:bg-red-800 cursor-pointer shrink-0"
          >
            Retry
          </button>
        </div>
      )}

      {/* Empty State */}
      {!loading && !error && tasks.length === 0 && (
        <div className="rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-12 text-center">
          <p className="font-display text-lg font-bold text-slate-900 dark:text-zinc-100">
            No matching tasks found
          </p>
          <p className="mt-1 text-sm text-slate-500 dark:text-zinc-400">
            {searchQuery || statusFilter !== 'All' || priorityFilter !== 'All'
              ? 'Try clearing your active search or filter criteria.'
              : 'Create a new task with a title, priority, and due date to get started.'}
          </p>
          <button
            type="button"
            onClick={onCreateTask}
            className="mt-5 inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Create Task</span>
          </button>
        </div>
      )}

      {/* Responsive Task Cards Grid */}
      {!loading && !error && tasks.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {tasks.map((task) => {
            const isCompleted = task.status === 'Completed';
            const isOverdue = !isCompleted && task.dueDate < todayIso;

            return (
              <article
                key={task.id}
                className="flex flex-col justify-between rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-5 hover:border-slate-300 dark:hover:border-zinc-700 transition-colors"
              >
                <div>
                  {/* Unboxed Metadata Line */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`font-semibold ${
                          task.priority === 'High'
                            ? 'text-red-600 dark:text-red-400'
                            : task.priority === 'Medium'
                              ? 'text-amber-600 dark:text-amber-400'
                              : 'text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {task.priority} Priority
                      </span>
                      <span aria-hidden="true" className="text-slate-400">
                        ·
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 font-medium ${
                          isCompleted
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : 'text-slate-600 dark:text-zinc-300'
                        }`}
                      >
                        {isCompleted ? (
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        ) : (
                          <Clock className="h-3.5 w-3.5" />
                        )}
                        {task.status}
                      </span>
                    </div>

                    <span
                      className={`inline-flex items-center gap-1 font-mono tabular-nums ${
                        isOverdue
                          ? 'font-semibold text-red-600 dark:text-red-400'
                          : 'text-slate-500 dark:text-zinc-400'
                      }`}
                    >
                      <Calendar className="h-3.5 w-3.5" />
                      {task.dueDate}
                      {isOverdue ? ' (Overdue)' : ''}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="mt-3 font-display text-base font-bold text-slate-950 dark:text-zinc-50">
                    <button
                      type="button"
                      onClick={() => onViewTask(task)}
                      className={`text-left hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer ${
                        isCompleted ? 'line-through text-slate-400 dark:text-zinc-500' : ''
                      }`}
                    >
                      {task.title}
                    </button>
                  </h3>

                  {/* Description */}
                  <p className="mt-1.5 text-sm text-slate-600 dark:text-zinc-400 line-clamp-2 leading-relaxed">
                    {task.description || 'No description provided.'}
                  </p>
                </div>

                {/* Actions Footer */}
                <div className="mt-5 pt-4 border-t border-slate-200/80 dark:border-zinc-800/80 flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => onToggleStatus(task)}
                    className={`min-h-[36px] inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                      isCompleted
                        ? 'border-slate-300 dark:border-zinc-700 text-slate-700 dark:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-900'
                        : 'border-emerald-200 dark:border-emerald-900/60 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-950/50'
                    }`}
                  >
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>{isCompleted ? 'Mark Pending' : 'Mark Completed'}</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onViewTask(task)}
                      className="min-h-[36px] rounded-lg border border-slate-200 dark:border-zinc-800 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-zinc-300 hover:border-slate-400 cursor-pointer"
                    >
                      Details
                    </button>
                    <button
                      type="button"
                      onClick={() => onEditTask(task)}
                      aria-label={`Edit ${task.title}`}
                      className="min-h-[36px] inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-zinc-800 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-zinc-300 hover:border-blue-600 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteTask(task)}
                      aria-label={`Delete ${task.title}`}
                      className="min-h-[36px] inline-flex items-center justify-center rounded-lg border border-red-200 dark:border-red-900/60 px-2.5 py-1.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
