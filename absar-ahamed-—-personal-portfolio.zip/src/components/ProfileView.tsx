import { useState, type FormEvent } from 'react';
import { AlertCircle, CheckCircle2, Loader2, Shield, User } from 'lucide-react';
import { updateUserProfile } from '../lib/api';
import type { TaskStats, UserProfile } from '../types';

interface ProfileViewProps {
  user: UserProfile;
  stats: TaskStats;
  token: string;
  onUserUpdated: (user: UserProfile) => void;
}

export function ProfileView({ user, stats, token, onUserUpdated }: ProfileViewProps) {
  const [name, setName] = useState(user.name);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null,
  );

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setFeedback(null);
    if (name.trim().length < 2) {
      setFeedback({ type: 'error', text: 'Display name must be at least 2 characters.' });
      return;
    }
    setSaving(true);
    try {
      const res = await updateUserProfile(name.trim(), token);
      onUserUpdated(res.user);
      setFeedback({ type: 'success', text: res.message });
    } catch (err) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : 'Unable to update profile.',
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight text-slate-950 dark:text-zinc-50">
          User Profile
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-zinc-400">
          Manage your account details and review your private task workspace summary.
        </p>
      </div>

      <div className="rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center gap-4 pb-6 border-b border-slate-200 dark:border-zinc-800">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-blue-600 text-lg font-bold text-white uppercase">
            {user.name.slice(0, 2)}
          </div>
          <div>
            <h2 className="font-display text-lg font-bold text-slate-950 dark:text-zinc-50">
              {user.name}
            </h2>
            <p className="text-sm text-slate-500 dark:text-zinc-400">{user.email}</p>
          </div>
        </div>

        <dl className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-950 p-4">
            <dt className="text-xs text-slate-500 dark:text-zinc-400">Account ID</dt>
            <dd className="mt-1 font-mono text-xs font-medium text-slate-900 dark:text-zinc-100 truncate">
              {user.id}
            </dd>
          </div>
          <div className="rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-950 p-4">
            <dt className="text-xs text-slate-500 dark:text-zinc-400">Member Since</dt>
            <dd className="mt-1 font-mono text-xs font-medium text-slate-900 dark:text-zinc-100 tabular-nums">
              {new Date(user.createdAt).toLocaleDateString()}
            </dd>
          </div>
          <div className="rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-950 p-4">
            <dt className="text-xs text-slate-500 dark:text-zinc-400">Total Tasks</dt>
            <dd className="mt-1 font-mono text-xs font-semibold text-slate-900 dark:text-zinc-100 tabular-nums">
              {stats.total} ({stats.completed} completed)
            </dd>
          </div>
        </dl>

        <form
          onSubmit={handleSubmit}
          className="pt-4 border-t border-slate-200 dark:border-zinc-800 space-y-4"
        >
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-zinc-300">
            <User className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <span>Update Display Name</span>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="flex-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3.5 py-2.5 text-sm text-slate-950 dark:text-zinc-100 focus:border-blue-600 focus:outline-none"
            />
            <button
              type="submit"
              disabled={saving}
              className="min-h-[42px] inline-flex items-center justify-center gap-2 rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60 cursor-pointer shrink-0"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              <span>Save Profile</span>
            </button>
          </div>

          {feedback && (
            <div
              role={feedback.type === 'error' ? 'alert' : 'status'}
              className={`flex items-start gap-2 rounded-lg border px-3.5 py-2.5 text-xs ${
                feedback.type === 'success'
                  ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200'
                  : 'border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950/40 text-red-900 dark:text-red-200'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              )}
              <span>{feedback.text}</span>
            </div>
          )}
        </form>

        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-zinc-400 pt-2">
          <Shield className="h-4 w-4 text-emerald-600 dark:text-emerald-500 shrink-0" />
          <span>Your tasks are strictly scoped to your authenticated user ID.</span>
        </div>
      </div>
    </div>
  );
}
