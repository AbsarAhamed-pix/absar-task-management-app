import {
  CheckCircle2,
  CheckSquare,
  Clock,
  LayoutDashboard,
  ListTodo,
  LogOut,
  UserCircle,
  X,
} from 'lucide-react';
import type { TaskPriority, TaskStats, UserProfile, WorkspaceView } from '../types';

interface SidebarProps {
  user: UserProfile;
  stats: TaskStats;
  activeView: WorkspaceView;
  activePriority: 'All' | TaskPriority;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onSelectView: (view: WorkspaceView, priority?: 'All' | TaskPriority) => void;
  onLogout: () => void;
}

export function Sidebar({
  user,
  stats,
  activeView,
  activePriority,
  mobileOpen,
  onCloseMobile,
  onSelectView,
  onLogout,
}: SidebarProps) {
  const navItems: {
    id: WorkspaceView;
    label: string;
    count?: number;
    icon: typeof LayoutDashboard;
  }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'all', label: 'All Tasks', count: stats.total, icon: ListTodo },
    { id: 'pending', label: 'Pending Tasks', count: stats.pending, icon: Clock },
    { id: 'completed', label: 'Completed Tasks', count: stats.completed, icon: CheckCircle2 },
    { id: 'profile', label: 'User Profile', icon: UserCircle },
  ];

  const priorityFilters: {
    priority: TaskPriority;
    label: string;
    count: number;
    colorClass: string;
  }[] = [
    {
      priority: 'High',
      label: 'High Priority',
      count: stats.highPriority,
      colorClass: 'text-red-600 dark:text-red-400',
    },
    {
      priority: 'Medium',
      label: 'Medium Priority',
      count: stats.mediumPriority,
      colorClass: 'text-amber-600 dark:text-amber-400',
    },
    {
      priority: 'Low',
      label: 'Low Priority',
      count: stats.lowPriority,
      colorClass: 'text-emerald-600 dark:text-emerald-400',
    },
  ];

  const sidebarContent = (
    <div className="flex h-full flex-col justify-between bg-white dark:bg-[#0C0C0E] border-r border-slate-200 dark:border-zinc-800">
      <div>
        {/* Brand */}
        <div className="flex h-16 items-center justify-between px-5 border-b border-slate-200 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <CheckSquare className="h-5 w-5 text-blue-600 dark:text-blue-500 shrink-0" />
            <span className="font-display text-base font-bold tracking-tight text-slate-950 dark:text-zinc-50 whitespace-nowrap">
              TaskFlow
            </span>
          </div>
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Close navigation sidebar"
            className="lg:hidden inline-flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-zinc-900 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Workspace Navigation */}
        <div className="p-4 space-y-6">
          <div>
            <p className="px-3 text-xs font-semibold text-slate-400 dark:text-zinc-500 mb-2">
              Workspace
            </p>
            <nav aria-label="Workspace navigation" className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isSelected = activeView === item.id && activePriority === 'All';
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onSelectView(item.id, 'All');
                      onCloseMobile();
                    }}
                    className={`w-full min-h-[40px] flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300'
                        : 'text-slate-700 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-900'
                    }`}
                  >
                    <span className="flex items-center gap-2.5 truncate">
                      <Icon className="h-4 w-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </span>
                    {typeof item.count === 'number' && (
                      <span className="font-mono text-xs tabular-nums text-slate-500 dark:text-zinc-400">
                        {item.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Priority Views */}
          <div>
            <p className="px-3 text-xs font-semibold text-slate-400 dark:text-zinc-500 mb-2">
              Priority Filter
            </p>
            <div className="space-y-1">
              {priorityFilters.map((item) => {
                const isSelected = activePriority === item.priority && activeView === 'all';
                return (
                  <button
                    key={item.priority}
                    type="button"
                    onClick={() => {
                      onSelectView('all', item.priority);
                      onCloseMobile();
                    }}
                    className={`w-full min-h-[38px] flex items-center justify-between rounded-lg px-3 py-1.5 text-sm font-medium transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-slate-100 dark:bg-zinc-900 text-slate-950 dark:text-zinc-50'
                        : 'text-slate-600 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-900'
                    }`}
                  >
                    <span className={item.colorClass}>{item.label}</span>
                    <span className="font-mono text-xs tabular-nums text-slate-500 dark:text-zinc-400">
                      {item.count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* User Account Footer */}
      <div className="border-t border-slate-200 dark:border-zinc-800 p-4 space-y-3">
        <div className="flex items-center gap-3 px-2">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-xs font-bold text-white uppercase">
            {user.name.slice(0, 2)}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-slate-900 dark:text-zinc-100">
              {user.name}
            </p>
            <p className="truncate text-xs text-slate-500 dark:text-zinc-400">{user.email}</p>
          </div>
        </div>

        <button
          type="button"
          onClick={onLogout}
          className="w-full min-h-[40px] flex items-center justify-center gap-2 rounded-lg border border-slate-200 dark:border-zinc-800 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-zinc-300 hover:bg-red-50 dark:hover:bg-red-950/30 hover:text-red-700 dark:hover:text-red-300 hover:border-red-200 dark:hover:border-red-900/60 transition-colors cursor-pointer"
        >
          <LogOut className="h-3.5 w-3.5" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Fixed Sidebar */}
      <aside className="hidden lg:block w-[260px] shrink-0">{sidebarContent}</aside>

      {/* Mobile / Tablet Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={onCloseMobile}
          />
          <aside className="relative z-10 w-[270px] max-w-[85vw] h-full">
            {sidebarContent}
          </aside>
        </div>
      )}
    </>
  );
}
