import { useState, type FormEvent } from 'react';
import {
  AlertCircle,
  CheckSquare,
  Eye,
  EyeOff,
  Loader2,
  Moon,
  ShieldCheck,
  Sun,
} from 'lucide-react';
import { loginUser, registerUser } from '../lib/api';
import type { UserProfile } from '../types';

interface AuthScreenProps {
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  onAuthenticated: (token: string, user: UserProfile) => void;
}

export function AuthScreen({ theme, onToggleTheme, onAuthenticated }: AuthScreenProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (mode === 'register' && name.trim().length < 2) {
      setError('Full name must be at least 2 characters.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) {
      setError('Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setLoading(true);
    try {
      const response =
        mode === 'register'
          ? await registerUser({
              name: name.trim(),
              email: email.trim(),
              password,
            })
          : await loginUser({
              email: email.trim(),
              password,
            });
      onAuthenticated(response.token, response.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] dark:bg-[#09090B] text-slate-900 dark:text-zinc-100">
      {/* Top Bar */}
      <header className="border-b border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#0C0C0E]">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
            <CheckSquare className="h-5 w-5 text-blue-600 dark:text-blue-500" />
            <span className="font-display text-lg font-bold tracking-tight">
              TaskFlow Workspace
            </span>
          </div>

          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-900 px-3.5 py-1.5 text-xs font-medium text-slate-700 dark:text-zinc-200 hover:border-slate-300 dark:hover:border-zinc-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            {theme === 'dark' ? (
              <>
                <Sun className="h-3.5 w-3.5 text-amber-500" />
                <span>Light</span>
              </>
            ) : (
              <>
                <Moon className="h-3.5 w-3.5 text-blue-600" />
                <span>Dark</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main Split Content */}
      <main className="flex-1 flex items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
        <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Side: Product Overview */}
          <div className="lg:col-span-6 space-y-6">
            <p className="font-mono text-xs font-medium text-blue-600 dark:text-blue-400">
              Thiranex Internship · Task 2 · Absar Ahamed
            </p>
            <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-950 dark:text-zinc-50 text-balance leading-tight">
              Personal Task Management Built on Verified Per-User Access.
            </h1>
            <p className="text-sm sm:text-base text-slate-600 dark:text-zinc-400 leading-relaxed max-w-xl">
              Organize priorities, track deadlines, filter pending and completed work, and sync changes across active sessions in real time with Socket.IO, Express, and MongoDB.
            </p>

            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-200 dark:border-zinc-800">
              <div className="rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 p-4">
                <dt className="text-xs text-slate-500 dark:text-zinc-400">Authentication</dt>
                <dd className="mt-1 text-sm font-semibold text-slate-900 dark:text-zinc-100">
                  JWT + Bcrypt Hashing
                </dd>
              </div>
              <div className="rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 p-4">
                <dt className="text-xs text-slate-500 dark:text-zinc-400">Data Isolation</dt>
                <dd className="mt-1 text-sm font-semibold text-slate-900 dark:text-zinc-100">
                  Strict Per-User Ownership
                </dd>
              </div>
            </dl>
          </div>

          {/* Right Side: Login / Register Card */}
          <div className="lg:col-span-6">
            <div className="rounded-2xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-6 sm:p-8">
              <div className="grid grid-cols-2 gap-1 rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-900 p-1 mb-6">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setError(null);
                  }}
                  className={`min-h-[40px] rounded-md text-xs sm:text-sm font-semibold transition-colors cursor-pointer ${
                    mode === 'login'
                      ? 'bg-slate-950 dark:bg-zinc-100 text-white dark:text-zinc-950'
                      : 'text-slate-600 dark:text-zinc-400 hover:text-slate-950 dark:hover:text-zinc-100'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setError(null);
                  }}
                  className={`min-h-[40px] rounded-md text-xs sm:text-sm font-semibold transition-colors cursor-pointer ${
                    mode === 'register'
                      ? 'bg-slate-950 dark:bg-zinc-100 text-white dark:text-zinc-950'
                      : 'text-slate-600 dark:text-zinc-400 hover:text-slate-950 dark:hover:text-zinc-100'
                  }`}
                >
                  Create Account
                </button>
              </div>

              <h2 className="font-display text-xl font-bold text-slate-950 dark:text-zinc-50">
                {mode === 'login' ? 'Sign in to your workspace' : 'Register a new account'}
              </h2>
              <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-zinc-400">
                {mode === 'login'
                  ? 'Enter your credentials to view and manage your private tasks.'
                  : 'Your password is salted and hashed with bcrypt before storage.'}
              </p>

              <form onSubmit={handleSubmit} noValidate className="mt-6 space-y-4">
                {mode === 'register' && (
                  <div>
                    <label
                      htmlFor="auth-name"
                      className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5"
                    >
                      Full Name
                    </label>
                    <input
                      id="auth-name"
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g., Absar Ahamed"
                      className="w-full rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3.5 py-2.5 text-sm text-slate-950 dark:text-zinc-100 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                    />
                  </div>
                )}

                <div>
                  <label
                    htmlFor="auth-email"
                    className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5"
                  >
                    Email Address
                  </label>
                  <input
                    id="auth-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3.5 py-2.5 text-sm text-slate-950 dark:text-zinc-100 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                  />
                </div>

                <div>
                  <label
                    htmlFor="auth-password"
                    className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5"
                  >
                    Password
                  </label>
                  <div className="relative">
                    <input
                      id="auth-password"
                      type={showPassword ? 'text' : 'password'}
                      required
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Minimum 6 characters"
                      className="w-full rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 pl-3.5 pr-11 py-2.5 text-sm text-slate-950 dark:text-zinc-100 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((prev) => !prev)}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 text-slate-500 hover:text-slate-800 dark:hover:text-zinc-200 cursor-pointer"
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>

                {error && (
                  <div
                    role="alert"
                    className="flex items-start gap-2.5 rounded-lg border border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950/40 px-3.5 py-2.5 text-xs text-red-900 dark:text-red-200"
                  >
                    <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60 transition-colors cursor-pointer"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>{mode === 'register' ? 'Creating Account...' : 'Signing In...'}</span>
                    </>
                  ) : (
                    <span>{mode === 'register' ? 'Create Account' : 'Sign In'}</span>
                  )}
                </button>
              </form>

              <div className="mt-5 pt-4 border-t border-slate-200 dark:border-zinc-800 flex items-center gap-2 text-xs text-slate-500 dark:text-zinc-400">
                <ShieldCheck className="h-4 w-4 text-emerald-600 dark:text-emerald-500 shrink-0" />
                <span>Protected by JWT authorization and per-user MongoDB task isolation.</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
