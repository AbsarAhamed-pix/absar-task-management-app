import { useEffect, useState, type FormEvent } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Clock,
  Loader2,
  Pencil,
  Trash2,
  X,
} from 'lucide-react';
import type { TaskPayload } from '../lib/api';
import type { TaskItem, TaskPriority, TaskStatus } from '../types';

interface TaskFormModalProps {
  open: boolean;
  editingTask: TaskItem | null;
  saving: boolean;
  error: string | null;
  onSave: (payload: TaskPayload) => void;
  onClose: () => void;
}

export function TaskFormModal({
  open,
  editingTask,
  saving,
  error,
  onSave,
  onClose,
}: TaskFormModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('Medium');
  const [status, setStatus] = useState<TaskStatus>('Pending');
  const [dueDate, setDueDate] = useState('');
  const [localError, setLocalError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setLocalError(null);
    if (editingTask) {
      setTitle(editingTask.title);
      setDescription(editingTask.description);
      setPriority(editingTask.priority);
      setStatus(editingTask.status);
      setDueDate(editingTask.dueDate);
    } else {
      setTitle('');
      setDescription('');
      setPriority('Medium');
      setStatus('Pending');
      setDueDate(new Date().toISOString().slice(0, 10));
    }
  }, [open, editingTask]);

  useEffect(() => {
    if (!open) return;
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [open, onClose]);

  if (!open) return null;

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLocalError(null);
    if (title.trim().length < 2) {
      setLocalError('Task title must be at least 2 characters.');
      return;
    }
    if (!dueDate) {
      setLocalError('Please choose a due date.');
      return;
    }
    onSave({
      title: title.trim(),
      description: description.trim(),
      priority,
      status,
      dueDate,
    });
  }

  const displayError = localError || error;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="task-form-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-zinc-800">
          <h2
            id="task-form-title"
            className="font-display text-lg font-bold text-slate-950 dark:text-zinc-50"
          >
            {editingTask ? 'Edit Task' : 'Create New Task'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 dark:border-zinc-800 text-slate-500 hover:bg-slate-100 dark:hover:bg-zinc-900 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} noValidate className="mt-5 space-y-4">
          <div>
            <label
              htmlFor="task-title"
              className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5"
            >
              Task Title
            </label>
            <input
              id="task-title"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Complete DBMS normalization assignment"
              className="w-full rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3.5 py-2.5 text-sm text-slate-950 dark:text-zinc-100 focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="task-desc"
              className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5"
            >
              Description
            </label>
            <textarea
              id="task-desc"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add notes, deliverables, or acceptance criteria..."
              className="w-full rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3.5 py-2.5 text-sm text-slate-950 dark:text-zinc-100 focus:border-blue-600 focus:outline-none resize-y"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="task-priority"
                className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5"
              >
                Priority
              </label>
              <select
                id="task-priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value as TaskPriority)}
                className="w-full rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3 py-2.5 text-sm text-slate-950 dark:text-zinc-100 focus:border-blue-600 focus:outline-none"
              >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="task-due"
                className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5"
              >
                Due Date
              </label>
              <input
                id="task-due"
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3 py-2.5 text-sm font-mono text-slate-950 dark:text-zinc-100 focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          {editingTask && (
            <div>
              <label
                htmlFor="task-status"
                className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5"
              >
                Status
              </label>
              <select
                id="task-status"
                value={status}
                onChange={(e) => setStatus(e.target.value as TaskStatus)}
                className="w-full rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3 py-2.5 text-sm text-slate-950 dark:text-zinc-100 focus:border-blue-600 focus:outline-none"
              >
                <option value="Pending">Pending</option>
                <option value="Completed">Completed</option>
              </select>
            </div>
          )}

          {displayError && (
            <div
              role="alert"
              className="flex items-start gap-2 rounded-lg border border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950/40 px-3.5 py-2.5 text-xs text-red-900 dark:text-red-200"
            >
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <span>{displayError}</span>
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[40px] rounded-lg border border-slate-300 dark:border-zinc-700 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-900 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="min-h-[40px] inline-flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-60 cursor-pointer"
            >
              {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              <span>{editingTask ? 'Save Changes' : 'Create Task'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

interface TaskDetailModalProps {
  task: TaskItem | null;
  onClose: () => void;
  onEdit: (task: TaskItem) => void;
  onDelete: (task: TaskItem) => void;
}

export function TaskDetailModal({ task, onClose, onEdit, onDelete }: TaskDetailModalProps) {
  useEffect(() => {
    if (!task) return;
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [task, onClose]);

  if (!task) return null;
  const todayIso = new Date().toISOString().slice(0, 10);
  const isOverdue = task.status === 'Pending' && task.dueDate < todayIso;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="task-detail-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-200 dark:border-zinc-800">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span
                className={`font-semibold ${
                  task.priority === 'High'
                    ? 'text-red-600 dark:text-red-400'
                    : task.priority === 'Medium'
                      ? 'text-amber-600 dark:text-amber-400'
                      : 'text-emerald-600 dark:text-emerald-400'
                }`}
              >
                {task.priority} Priority
              </span>
              <span aria-hidden="true" className="text-slate-400">
                ·
              </span>
              <span className="inline-flex items-center gap-1 font-medium text-slate-700 dark:text-zinc-300">
                {task.status === 'Completed' ? (
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <Clock className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
                )}
                {task.status}
              </span>
            </div>
            <h2
              id="task-detail-title"
              className="mt-2 font-display text-xl font-bold text-slate-950 dark:text-zinc-50"
            >
              {task.title}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close task details"
            className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-200 dark:border-zinc-800 text-slate-500 hover:bg-slate-100 dark:hover:bg-zinc-900 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="py-5 space-y-5">
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-zinc-400">Description</p>
            <p className="mt-1.5 text-sm leading-relaxed text-slate-700 dark:text-zinc-300 whitespace-pre-wrap">
              {task.description || 'No description provided for this task.'}
            </p>
          </div>

          <dl className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-200 dark:border-zinc-800">
            <div>
              <dt className="text-xs text-slate-500 dark:text-zinc-400">Due Date</dt>
              <dd
                className={`mt-1 inline-flex items-center gap-1 font-mono text-xs font-semibold tabular-nums ${
                  isOverdue ? 'text-red-600 dark:text-red-400' : 'text-slate-900 dark:text-zinc-100'
                }`}
              >
                <Calendar className="h-3.5 w-3.5" />
                {task.dueDate}
                {isOverdue ? ' (Overdue)' : ''}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500 dark:text-zinc-400">Created</dt>
              <dd className="mt-1 font-mono text-xs text-slate-700 dark:text-zinc-300 tabular-nums">
                {new Date(task.createdAt).toLocaleDateString()}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500 dark:text-zinc-400">Last Updated</dt>
              <dd className="mt-1 font-mono text-xs text-slate-700 dark:text-zinc-300 tabular-nums">
                {new Date(task.updatedAt).toLocaleDateString()}
              </dd>
            </div>
          </dl>
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-zinc-800">
          <button
            type="button"
            onClick={() => {
              onClose();
              onDelete(task);
            }}
            className="min-h-[38px] inline-flex items-center gap-1.5 rounded-lg border border-red-200 dark:border-red-900/60 px-3.5 py-1.5 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Delete</span>
          </button>
          <button
            type="button"
            onClick={() => {
              onClose();
              onEdit(task);
            }}
            className="min-h-[38px] inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
          >
            <Pencil className="h-3.5 w-3.5" />
            <span>Edit Task</span>
          </button>
        </div>
      </div>
    </div>
  );
}

interface DeleteConfirmModalProps {
  task: TaskItem | null;
  deleting: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export function DeleteConfirmModal({
  task,
  deleting,
  onConfirm,
  onCancel,
}: DeleteConfirmModalProps) {
  if (!task) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="delete-confirm-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs"
      onClick={onCancel}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#121216] p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400">
            <AlertTriangle className="h-5 w-5" />
          </div>
          <div>
            <h2
              id="delete-confirm-title"
              className="font-display text-base font-bold text-slate-950 dark:text-zinc-50"
            >
              Delete Task?
            </h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-zinc-400">
              Are you sure you want to delete <span className="font-semibold text-slate-900 dark:text-zinc-100">"{task.title}"</span>? This action cannot be undone.
            </p>
          </div>
        </div>

        <div className="mt-6 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            disabled={deleting}
            className="min-h-[40px] rounded-lg border border-slate-300 dark:border-zinc-700 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-900 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={deleting}
            className="min-h-[40px] inline-flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-xs font-semibold text-white hover:bg-red-700 disabled:opacity-60 cursor-pointer"
          >
            {deleting && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            <span>Confirm Delete</span>
          </button>
        </div>
      </div>
    </div>
  );
}
